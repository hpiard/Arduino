#!/bin/sh
#------------------------------------------------
# This shell script is designed to update the
# megaraid_sas driver on Ubuntu 16.04.3
# Created date: 11/7/2017
# Version: 0.1.0
# Author: Neo Cui
#------------------------------------------------
info="Update megaraid_sas driver (post-install)..."
echo $info
cmd=`cp /mnt/megaraid_sas_update/megaraid_sas_new.deb /target/mnt`
cmd=`in-target dpkg -i /mnt/megaraid_sas_new.deb`