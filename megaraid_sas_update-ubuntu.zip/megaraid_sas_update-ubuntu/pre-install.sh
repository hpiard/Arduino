#!/bin/sh
#------------------------------------------------
# This shell script is designed to update the
# megaraid_sas driver on Ubuntu 16.04.3
# Created date: 11/7/2017
# Version: 0.1.0
# Author: Neo Cui
#------------------------------------------------
info="Update megaraid_sas driver (pre-install)..."
echo $info
cmd=`ar -x megaraid_sas_new.deb data.tar.xz`
cmd=`xzcat data.tar.xz > data.tar`
cmd=`tar -xvf data.tar`
cmd=`mv /mnt/megaraid_sas_update/lib/modules/4.4.0-87-generic/weak-updates/megaraid_sas/megaraid_sas.ko.new /lib/modules/4.4.0-87-generic/kernel/drivers/scsi/megaraid/megaraid_sas.ko`
cmd=`rm -rf *.xz *.tar`
cmd=`insmod /lib/modules/4.4.0-87-generic/kernel/drivers/scsi/megaraid/megaraid_sas.ko`
